import streamlit as st
from streamlit_ace import st_ace
import streamlit.components.v1 as components
import os
import re
import glob
import markdown
import base64
from pathlib import Path
import importlib.util
import sys
from io import StringIO
import contextlib
import json
from datetime import datetime, date
import calendar
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.backends.backend_agg import FigureCanvasAgg
import io
import traceback
# Constants
PROBLEMS_DIR = "Problems"
SUPPORTED_EXTENSIONS = ['.md', '.html', '.py']
USER_DATA_FILE = "user_data.json"

# Utility Functions
def get_problem_directories():
    """Get all problem directories sorted numerically"""
    if not os.path.exists(PROBLEMS_DIR):
        os.makedirs(PROBLEMS_DIR)
        
    problem_dirs = [d for d in os.listdir(PROBLEMS_DIR) 
                   if os.path.isdir(os.path.join(PROBLEMS_DIR, d))]
    
    def get_number(dirname):
        match = re.match(r'(\d+)_', dirname)
        return int(match.group(1)) if match else float('inf')
    
    return sorted(problem_dirs, key=get_number)

def load_file_content(file_path):
    """Load and return file content with proper encoding"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        st.error(f"Error loading file: {e}")
        return ""

def save_file_content(file_path, content):
    """Save content to file with proper encoding"""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
        st.success(f"Successfully saved changes to {file_path}")
    except Exception as e:
        st.error(f"Error saving file: {e}")

def render_math_content(content, file_ext):
    """Render content with MathJax support"""
    if file_ext == '.md':
        content = markdown.markdown(content)
    
    content = re.sub(r'\\\(', r'$', content)
    content = re.sub(r'\\\)', r'$', content)
    content = re.sub(r'\\\[', r'$$', content)
    content = re.sub(r'\\\]', r'$$', content)
    
    return components.html(
        f"""
        <div style="padding: 20px;">
            {content}
        </div>
        <script>
            window.MathJax = {{
                tex: {{
                    inlineMath: [['$', '$'], ['\\\\(', '\\\\)']],
                    displayMath: [['$$', '$$'], ['\\\\[', '\\\\]']]
                }},
                svg: {{
                    fontCache: 'global'
                }}
            }};
        </script>
        <script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
        """,
        height=600,
        scrolling=True
    )

def get_problem_solutions(problem_dir):
    """Get all solution files for a problem"""
    solutions = []
    if os.path.exists(problem_dir):
        for file in os.listdir(problem_dir):
            if file.startswith('solution') and file.endswith('.py'):
                solutions.append(file)
    return sorted(solutions)

# User Progress Management
class UserProgress:
    def __init__(self):
        self.load_user_data()
    
    def load_user_data(self):
        if os.path.exists(USER_DATA_FILE):
            with open(USER_DATA_FILE, 'r') as f:
                self.data = json.load(f)
        else:
            self.data = {
                "completed_problems": [],
                "daily_progress": {},
                "current_streak": 0,
                "last_daily_challenge": None
            }
    
    def save_user_data(self):
        with open(USER_DATA_FILE, 'w') as f:
            json.dump(self.data, f)
    
    def mark_problem_complete(self, problem_id):
        if problem_id not in self.data["completed_problems"]:
            self.data["completed_problems"].append(problem_id)
            today = date.today().isoformat()
            self.data["daily_progress"][today] = self.data["daily_progress"].get(today, 0) + 1
            self.update_streak()
            self.save_user_data()
    
    def update_streak(self):
        today = date.today()
        streak = 0
        current_date = today
        
        while current_date.isoformat() in self.data["daily_progress"]:
            streak += 1
            current_date = current_date.replace(day=current_date.day - 1)
        
        self.data["current_streak"] = streak

# UI Components
def setup_page():
    """Configure the Streamlit page settings"""
    st.set_page_config(
        page_title="Deep-ML Interactive Platform",
        page_icon="📚",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Custom CSS
    st.markdown("""
        <style>
        .stButton button {
            width: 100%;
        }
        .stProgress > div > div > div {
            background-color: #4CAF50;
        }
        </style>
    """, unsafe_allow_html=True)

def render_header():
    """Render the application header with navigation"""
    col1, col2, col3, col4, col5 = st.columns([2, 1, 1, 1, 1])
    with col1:
        st.title("Deep-ML")
    with col2:
        if st.button("Problems", key="nav_problems"):
            st.session_state["page"] = "problem_explorer"
    with col3:
        if st.button("Daily Challenge", key="nav_challenge"):
            st.session_state["page"] = "daily_challenge"
    with col4:
        if st.button("Submit Problem", key="nav_submit"):
            st.session_state["page"] = "submit_problem"
    with col5:
        if st.button("Profile", key="nav_profile"):
            st.session_state["page"] = "profile"

def get_problem_metadata():
    """Get metadata for all problems including difficulty and category"""
    problems = []
    for problem_dir in get_problem_directories():
        match = re.match(r'(\d+)_(.+)', problem_dir)
        if match:
            number, name = match.groups()
            
            # Determine difficulty and category
            if int(number) < 10:
                difficulty = "easy"
            elif int(number) < 20:
                difficulty = "medium"
            else:
                difficulty = "hard"
            
            # Determine category based on content
            name_lower = name.lower()
            if "matrix" in name_lower or "eigen" in name_lower:
                category = "Linear Algebra"
            elif "regression" in name_lower or "learning" in name_lower:
                category = "Machine Learning"
            elif "tree" in name_lower or "graph" in name_lower:
                category = "Data Structures"
            else:
                category = "Mathematics"
            
            problems.append({
                "id": int(number),
                "title": name.replace('_', ' '),
                "difficulty": difficulty,
                "category": category,
                "directory": problem_dir
            })
    
    return sorted(problems, key=lambda x: x["id"])

def render_problem_explorer():
    """Render the problem explorer with filtering and sorting"""
    st.header("Problem Explorer")
    
    # Filters
    col1, col2, col3 = st.columns(3)
    
    with col1:
        difficulty_filter = st.selectbox(
            "Difficulty",
            ["All", "Easy", "Medium", "Hard"],
            key="difficulty_filter"
        )
    
    with col2:
        categories = ["All", "Linear Algebra", "Machine Learning", 
                     "Data Structures", "Mathematics"]
        category_filter = st.selectbox(
            "Category",
            categories,
            key="category_filter"
        )
    
    with col3:
        search = st.text_input("Search", key="problem_search")
    
    # Get and filter problems
    problems = get_problem_metadata()
    
    if difficulty_filter != "All":
        problems = [p for p in problems if p["difficulty"].lower() == difficulty_filter.lower()]
    if category_filter != "All":
        problems = [p for p in problems if p["category"] == category_filter]
    if search:
        problems = [p for p in problems if search.lower() in p["title"].lower()]
    
    # Display problems
    render_problems_table(problems)

def render_problems_table(problems):
    """Render the problems in a table format"""
    for idx, problem in enumerate(problems):
        with st.container():
            cols = st.columns([1, 3, 2, 2, 2])
            
            # Problem ID and Title
            cols[0].write(f"#{problem['id']}")
            cols[1].write(problem["title"])
            
            # Difficulty with color coding
            difficulty_colors = {
                "easy": "green",
                "medium": "orange",
                "hard": "red"
            }
            cols[2].markdown(
                f'<span style="color: {difficulty_colors[problem["difficulty"]]}">'
                f'{problem["difficulty"].capitalize()}</span>',
                unsafe_allow_html=True
            )
            
            # Category
            cols[3].write(problem["category"])
            
            # Actions
            if cols[4].button("Solve", key=f"solve_{problem['id']}_{idx}"):
                st.session_state["current_problem"] = problem
                st.session_state["page"] = "problem_solver"
            
            st.markdown("---")

def execute_code(code):
    """Execute code and return outputs and errors"""
    namespace = {}
    with StringIO() as out, StringIO() as err:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            try:
                exec(code, namespace)
            except Exception as e:
                err.write(str(e))
        return out.getvalue(), err.getvalue()

# def render_problem_solver(problem):
#     """Render the problem solving environment"""
#     st.header(f"Problem {problem['id']}: {problem['title']}")
    
#     problem_path = os.path.join(PROBLEMS_DIR, problem['directory'])
    
#     # Create tabs
#     tabs = st.tabs(["Description", "Editor", "Solutions"])
    
#     # Description Tab
#     with tabs[0]:
#         description_file = next(
#             (f for f in os.listdir(problem_path) if f.startswith("learn.")),
#             None
#         )
#         if description_file:
#             content = load_file_content(os.path.join(problem_path, description_file))
#             render_math_content(content, os.path.splitext(description_file)[1])
    
#     # Editor Tab
#     with tabs[1]:
#         st.write("## Code Editor")
#         code = st_ace(
#             placeholder="Write your solution here...",
#             language="python",
#             theme="monokai",
#             key=f"editor_{problem['id']}",
#             height=400
#         )
        
#         col1, col2 = st.columns(2)
        
#         with col1:
#             if st.button("Run Code", key=f"run_{problem['id']}"):
#                 output, error = execute_code(code)
#                 if output:
#                     st.write("### Output:")
#                     st.code(output)
#                 if error:
#                     st.error(f"Errors:\n{error}")
        
#         with col2:
#             if st.button("Submit", key=f"submit_{problem['id']}"):
#                 solution_name = st.text_input(
#                     "Save solution as:",
#                     value=f"solution_{len(get_problem_solutions(problem_path)) + 1}.py",
#                     key=f"solution_name_{problem['id']}"
#                 )
#                 if st.button("Save Solution", key=f"save_{problem['id']}"):
#                     save_file_content(
#                         os.path.join(problem_path, solution_name),
#                         code
#                     )
#                     st.session_state.user_progress.mark_problem_complete(problem['id'])
    
#     # Solutions Tab
#     with tabs[2]:
#         solutions = get_problem_solutions(problem_path)
#         if solutions:
#             selected_solution = st.selectbox(
#                 "Select Solution",
#                 solutions,
#                 key=f"solution_select_{problem['id']}"
#             )
            
#             if selected_solution:
#                 solution_content = load_file_content(
#                     os.path.join(problem_path, selected_solution)
#                 )
#                 with st.container(height=400):  # Scrollable container
#                     st.code(solution_content, language='python')
                
#                 if st.button("Run Solution", key=f"run_solution_{problem['id']}"):
#                     output, error = execute_code(solution_content)
#                     if output:
#                         st.write("### Output:")
#                         st.code(output)
#                     if error:
#                         st.error(f"Errors:\n{error}")
#         else:
#             st.info("No solutions available yet.")


import streamlit as st
from streamlit_ace import st_ace
import streamlit.components.v1 as components
import os
import re
import glob
import markdown
import base64
from pathlib import Path
import importlib.util
import sys
from io import StringIO
import contextlib
import json
from datetime import datetime, date
import calendar
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.backends.backend_agg import FigureCanvasAgg
import io
import traceback

class CodeExecutor:
    def __init__(self):
        self.allowed_modules = {
            'numpy': 'np',
            'pandas': 'pd',
            'matplotlib.pyplot': 'plt',
            'seaborn': 'sns',
            'math': 'math',
            'statistics': 'statistics',
            'random': 'random',
            'datetime': 'datetime',
            'collections': 'collections'
        }
        
    def setup_execution_environment(self):
        """Set up a clean environment with allowed modules"""
        namespace = {}
        for module_name, alias in self.allowed_modules.items():
            try:
                module = importlib.import_module(module_name)
                namespace[alias] = module
            except ImportError:
                pass
        return namespace

    def capture_matplotlib_output(self):
        """Capture matplotlib figure as bytes"""
        if plt.get_fignums():
            buf = io.BytesIO()
            plt.savefig(buf, format='png', bbox_inches='tight')
            plt.close('all')
            buf.seek(0)
            return buf.getvalue()
        return None

    def execute_code(self, code):
        """Execute code and return outputs, errors, and plots"""
        output_buffer = StringIO()
        error_buffer = StringIO()
        namespace = self.setup_execution_environment()
        
        try:
            with contextlib.redirect_stdout(output_buffer), \
                 contextlib.redirect_stderr(error_buffer):
                
                # Execute the code
                exec(code, namespace)
                
                # Capture any matplotlib output
                plot_data = self.capture_matplotlib_output()
                
                return {
                    'output': output_buffer.getvalue(),
                    'error': error_buffer.getvalue(),
                    'plot': plot_data,
                    'variables': self.get_variable_state(namespace)
                }
                
        except Exception as e:
            error_msg = f"Error: {str(e)}\n{traceback.format_exc()}"
            return {
                'output': output_buffer.getvalue(),
                'error': error_msg,
                'plot': None,
                'variables': {}
            }

    def get_variable_state(self, namespace):
        """Get the state of variables after execution"""
        variables = {}
        for key, value in namespace.items():
            if not key.startswith('__') and key not in self.allowed_modules.values():
                try:
                    if isinstance(value, (int, float, str, bool, list, dict)):
                        variables[key] = str(value)
                    elif isinstance(value, (np.ndarray, pd.DataFrame)):
                        variables[key] = f"{type(value).__name__} with shape {value.shape}"
                except:
                    pass
        return variables

def render_code_output(execution_result):
    """Render code execution output in Streamlit"""
    if execution_result['output']:
        st.write("### Output:")
        st.code(execution_result['output'])
    
    if execution_result['error']:
        st.error(execution_result['error'])
    
    if execution_result['plot']:
        st.write("### Plot Output:")
        st.image(execution_result['plot'])
    
    if execution_result['variables']:
        st.write("### Variable State:")
        for var_name, var_value in execution_result['variables'].items():
            st.code(f"{var_name}: {var_value}")

def render_problem_solver(problem):
    """Enhanced problem solver with code execution"""
    st.header(f"Problem {problem['id']}: {problem['title']}")
    
    problem_path = os.path.join(PROBLEMS_DIR, problem['directory'])
    
    # Create tabs
    tabs = st.tabs(["Description", "Editor", "Solutions"])
    
    # Description Tab
    with tabs[0]:
        description_file = next(
            (f for f in os.listdir(problem_path) if f.startswith("learn.")),
            None
        )
        if description_file:
            content = load_file_content(os.path.join(problem_path, description_file))
            render_math_content(content, os.path.splitext(description_file)[1])
    
    # Editor Tab
    with tabs[1]:
        st.write("## Code Editor")
        
        # Add template code button
        if st.button("Load Template"):
            template_code = """import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Your code here
"""
            st.session_state[f"editor_{problem['id']}"] = template_code
        
        # Code editor
        code = st_ace(
            value=st.session_state.get(f"editor_{problem['id']}", ""),
            placeholder="Write your solution here...",
            language="python",
            theme="monokai",
            key=f"editor_{problem['id']}",
            height=400
        )
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Run Code", key=f"run_{problem['id']}"):
                executor = CodeExecutor()
                result = executor.execute_code(code)
                render_code_output(result)
        
        with col2:
            if st.button("Submit", key=f"submit_{problem['id']}"):
                solution_name = st.text_input(
                    "Save solution as:",
                    value=f"solution_{len(get_problem_solutions(problem_path)) + 1}.py",
                    key=f"solution_name_{problem['id']}"
                )
                if st.button("Save Solution", key=f"save_{problem['id']}"):
                    save_file_content(
                        os.path.join(problem_path, solution_name),
                        code
                    )
                    st.session_state.user_progress.mark_problem_complete(problem['id'])
    
    # Solutions Tab
    with tabs[2]:
        solutions = get_problem_solutions(problem_path)
        if solutions:
            selected_solution = st.selectbox(
                "Select Solution",
                solutions,
                key=f"solution_select_{problem['id']}"
            )
            
            if selected_solution:
                solution_content = load_file_content(
                    os.path.join(problem_path, selected_solution)
                )
                with st.container(height=400):
                    st.code(solution_content, language='python')
                
                if st.button("Run Solution", key=f"run_solution_{problem['id']}"):
                    executor = CodeExecutor()
                    result = executor.execute_code(solution_content)
                    render_code_output(result)
        else:
            st.info("No solutions available yet.")


def render_daily_challenge():
    """Render the daily challenge"""
    st.header("Daily Challenge")
    
    today = date.today()
    problems = get_problem_metadata()
    
    if problems:
        # Select a problem based on the date
        problem_index = today.toordinal() % len(problems)
        problem = problems[problem_index]
        
        st.write(f"### Problem {problem['id']}: {problem['title']}")
        st.write(f"**Difficulty:** {problem['difficulty'].capitalize()}")
        st.write(f"**Category:** {problem['category']}")
        
        if st.button("Start Challenge", key="start_daily_challenge"):
            st.session_state["current_problem"] = problem
            st.session_state["page"] = "problem_solver"
    else:
        st.warning("No problems available for daily challenge.")

def render_user_profile():
    """Render user profile and statistics"""
    st.header("Your Profile")
    
    # Statistics
    col1, col2, col3 = st.columns(3)
    
    with col1:
        total_problems = len(get_problem_directories())
        completed = len(st.session_state.user_progress.data["completed_problems"])
        completion_rate = (completed / total_problems * 100) if total_problems > 0 else 0
        st.metric("Completion Rate", f"{completion_rate:.1f}%")
    
    with col2:
        st.metric("Problems Solved", completed)
    
    with col3:
        st.metric("Current Streak", f"{st.session_state.user_progress.data['current_streak']} days")
    
    # Progress Calendar
    st.write("## Progress Calendar")
    today = date.today()
    cal = calendar.monthcalendar(today.year, today.month)
    
    # Create calendar grid
    cols = st.columns(7)
    for i, day in enumerate(["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]):
        cols[i].write(f"**{day}**")
    
    for week in cal:
        cols = st.columns(7)
        for i, day in enumerate(week):
            if day == 0:
                cols[i].write("")
            else:
                date_str = f"{today.year}-{today.month:02d}-{day:02d}"
                if date_str in st.session_state.user_progress.data["daily_progress"]:
                    cols[i].markdown(f"**{day}** ✅")
                else:
                    cols[i].write(str(day))
    
    # Problem History
    st.write("## Problem History")
    if completed > 0:
        problems = get_problem_metadata()
        completed_problems = [p for p in problems 
                            if p["id"] in st.session_state.user_progress.data["completed_problems"]]
        
        for problem in completed_problems:
            with st.expander(f"Problem {problem['id']}: {problem['title']}"):
                st.write(f"**Category:** {problem['category']}")
                st.write(f"**Difficulty:** {problem['difficulty'].capitalize()}")
                
                # Show solutions
                problem_path = os.path.join(PROBLEMS_DIR, problem['directory'])
                solutions = get_problem_solutions(problem_path)
                if solutions:
                    st.write("**Your Solutions:**")
                    for solution in solutions:
                        st.code(load_file_content(os.path.join(problem_path, solution)), 
                               language='python')
    else:
        st.info("You haven't solved any problems yet. Start solving to build your history!")

def render_submit_problem():
    """Render the problem submission form"""
    st.header("Submit a New Problem")
    
    with st.form("problem_submission"):
        st.write("### Problem Details")
        
        col1, col2 = st.columns(2)
        
        with col1:
            problem_number = st.number_input(
                "Problem Number",
                min_value=1,
                help="Must be unique"
            )
            
            problem_title = st.text_input(
                "Problem Title",
                help="A descriptive title for the problem"
            )
            
            difficulty = st.selectbox(
                "Difficulty Level",
                ["Easy", "Medium", "Hard"]
            )
        
        with col2:
            category = st.selectbox(
                "Category",
                ["Linear Algebra", "Machine Learning", "Data Structures", "Mathematics"]
            )
            
            tags = st.text_input(
                "Tags",
                help="Comma-separated tags"
            )
        
        st.write("### Problem Content")
        
        description = st.text_area(
            "Problem Description (Markdown)",
            height=200,
            help="Support Markdown and LaTeX"
        )
        
        sample_solution = st.text_area(
            "Sample Solution",
            height=200,
            help="Python code"
        )
        
        submitted = st.form_submit_button("Submit Problem")
        
        if submitted:
            try:
                # Create problem directory
                problem_dir = f"{problem_number}_{problem_title.replace(' ', '_')}"
                problem_path = os.path.join(PROBLEMS_DIR, problem_dir)
                os.makedirs(problem_path, exist_ok=True)
                
                # Save description
                with open(os.path.join(problem_path, 'learn.md'), 'w') as f:
                    f.write(description)
                
                # Save sample solution
                with open(os.path.join(problem_path, 'solution.py'), 'w') as f:
                    f.write(sample_solution)
                
                st.success("Problem submitted successfully!")
                
            except Exception as e:
                st.error(f"Error submitting problem: {str(e)}")

def main():
    """Main application function"""
    setup_page()
    
    # Initialize session state
    if "page" not in st.session_state:
        st.session_state["page"] = "home"
    if "user_progress" not in st.session_state:
        st.session_state["user_progress"] = UserProgress()
    if "current_problem" not in st.session_state:
        st.session_state["current_problem"] = None
    if "nav_selection" not in st.session_state:
        st.session_state["nav_selection"] = "Home"
    
    # Render header
    render_header()
    
    # Sidebar navigation
    with st.sidebar:
        st.title("Navigation")
        current_nav = st.radio(
            "Go to",
            ["Home", "Problem Explorer", "Daily Challenge", "Profile", "Submit Problem"],
            key="navigation",
            index=["Home", "Problem Explorer", "Daily Challenge", "Profile", "Submit Problem"].index(st.session_state["nav_selection"])
        )
        
        # Update navigation state
        if current_nav != st.session_state["nav_selection"]:
            st.session_state["nav_selection"] = current_nav
            st.session_state["page"] = current_nav.lower().replace(" ", "_")
    
    # Main content
    if st.session_state["page"] == "home":
        render_daily_challenge()
        st.markdown("---")
        render_problem_explorer()
    
    elif st.session_state["page"] == "problem_explorer":
        render_problem_explorer()
    
    elif st.session_state["page"] == "daily_challenge":
        render_daily_challenge()
    
    elif st.session_state["page"] == "profile":
        render_user_profile()
    
    elif st.session_state["page"] == "submit_problem":
        render_submit_problem()
    
    elif st.session_state["page"] == "problem_solver" and st.session_state["current_problem"]:
        render_problem_solver(st.session_state["current_problem"])

if __name__ == "__main__":
    main()